import React from 'react';
import './Footer.css';

export default function Footer() {
  return (
    <div className='footer-body'>
        <div className='footer-container'>
            <div className='contact-info'>
                Contact Info
            </div>
            <div>
                LSL Tools Private LTD
            </div>
            <div className='location'>
                <div className='icon-images'></div>
                <div className='location-details'>Plot no 394 , phase-lll , Udyog vihar , Gurgaon Haryana- 122016</div>
            </div>
            <div className='phone-no'>
                <div className='icon-images'></div>
                <div className='location-details'>+91 124000608</div>
            </div>
          
            <div className='location-details'>
                Sales@Xtrapowertool.com
            </div>
        </div>

    </div>
  )
}

